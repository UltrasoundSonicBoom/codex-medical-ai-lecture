const lessons = [
  {
    id: "lesson-start",
    nav: "시작 전 준비",
    title: "시작 전 준비",
    goal: "수강생이 같은 폴더, 같은 화면, 같은 실습 순서에서 출발하도록 정렬합니다.",
    duration: "5분",
    output: "실습 환경 확인",
    files: [
      "index.html",
      "samples/",
      "assets/",
      "docs/source_notes.md"
    ],
    checks: [
      "ZIP 파일을 압축 해제했습니다.",
      "Codex에서 실습 폴더를 프로젝트로 선택했습니다.",
      "샘플 파일 위치를 확인했습니다."
    ],
    instructorNote: "처음 5분은 기능 설명보다 환경 정렬이 중요합니다. 수강생에게 ZIP 안에서 바로 실행하지 말고 반드시 압축 해제 후 index.html을 열도록 안내하세요.",
    steps: [
      {
        title: "압축 해제 후 HTML 열기",
        body: "ZIP 파일을 압축 해제한 뒤 폴더 안의 index.html을 브라우저로 엽니다.",
        prompt: "이 단계는 Codex 프롬프트가 없습니다. 먼저 실습 패키지 폴더 구조를 확인하세요."
      },
      {
        title: "Codex 프로젝트 폴더 선택",
        body: "Codex에서 이 실습 패키지 폴더를 프로젝트로 선택합니다.",
        prompt: "이 폴더의 구조를 먼저 확인하고, 어떤 실습 파일들이 있는지 간단히 요약해줘."
      },
      {
        title: "실습 규칙 확인",
        body: "삭제, 이동, 의료 판단은 자동 실행하지 않고 먼저 계획과 검토를 거칩니다.",
        prompt: "앞으로 이 폴더에서 실습할 때 파일 삭제나 이동은 먼저 계획과 dry run을 만든 뒤 진행해줘. 의료 관련 문서는 교육용 초안으로만 다뤄줘."
      }
    ]
  },
  {
    id: "lesson-assistant-agent",
    nav: "1강: Assistant vs Agent",
    title: "1강. AI를 활용하는 두 가지 관점",
    goal: "ChatGPT는 답을 주는 Assistant, Codex는 일을 수행하는 Agent라는 차이를 이해합니다.",
    duration: "8분",
    output: "개념 구분",
    files: ["docs/instructor_script.md"],
    checks: [
      "Assistant와 Agent 차이를 말로 설명할 수 있습니다.",
      "답변과 결과물의 차이를 구분했습니다.",
      "Codex 실습의 목적을 이해했습니다."
    ],
    instructorNote: "이 슬라이드에서는 기능 목록을 많이 설명하지 말고, '답을 받는 것'과 '파일을 받는 것'의 차이에 집중하세요.",
    steps: [
      {
        title: "Assistant 개념 확인",
        body: "사용자가 질문하면 AI가 설명, 코드, 가이드처럼 답변을 제공합니다.",
        prompt: "엑셀에서 VLOOKUP 함수를 어떻게 쓰는지 예시 데이터와 함께 설명해줘."
      },
      {
        title: "Agent 개념 확인",
        body: "사용자가 해야 할 일을 AI가 직접 수행하고, 파일 형태의 결과물을 남깁니다.",
        prompt: "이 폴더의 샘플 CSV를 분석해서 Excel 파일로 정리하고, 요약 시트와 차트 시트를 포함해줘."
      },
      {
        title: "역할 차이 한 문장으로 정리",
        body: "강의의 핵심 메시지를 수강생 언어로 고정합니다.",
        prompt: "ChatGPT와 Codex의 차이를 비개발자도 이해할 수 있게 한 문장과 예시 2개로 정리해줘."
      }
    ]
  },
  {
    id: "lesson-chatgpt-limit",
    nav: "2강: ChatGPT 활용과 한계",
    title: "2강. ChatGPT 실무 활용 예시와 한계",
    goal: "ChatGPT를 지식 습득과 업무 가이드에 쓰고, 실제 파일 산출은 Codex로 넘기는 기준을 잡습니다.",
    duration: "10분",
    output: "업무 전환 기준",
    files: ["prompts/prompts.json"],
    checks: [
      "ChatGPT로 학습할 주제를 정했습니다.",
      "Codex로 넘길 파일 작업을 구분했습니다.",
      "복사-실행-저장의 부담을 인식했습니다."
    ],
    instructorNote: "ChatGPT를 낮춰 말할 필요는 없습니다. 좋은 조력자이지만, 이번 수업에서는 파일로 끝나는 작업을 Codex에게 맡기는 전환이 핵심이라고 안내하세요.",
    steps: [
      {
        title: "지식 학습 요청",
        body: "함수, 개념, 기준을 빠르게 배우는 용도로 사용합니다.",
        prompt: "엑셀 VLOOKUP 함수의 원리와 자주 틀리는 부분을 예시 데이터로 설명해줘."
      },
      {
        title: "업무 기준 요청",
        body: "파일 정리 기준, 디자인 팁, 요약 기준처럼 판단 기준을 얻습니다.",
        prompt: "다운로드 폴더를 효율적으로 정리하는 기준을 알려줘. 카테고리 분류 기준과 중복 파일 처리 원칙도 함께 정리해줘."
      },
      {
        title: "한계 확인",
        body: "답변을 실제 파일에 적용하고 저장하는 일은 여전히 사용자가 해야 합니다.",
        prompt: "위 기준을 실제 폴더에 적용하려면 사용자가 직접 해야 하는 단계와 Codex에게 맡길 수 있는 단계를 나눠줘."
      }
    ]
  },
  {
    id: "lesson-codex-setup",
    nav: "3강-1: Codex 세팅",
    title: "3강-1. Codex 프로젝트 환경 세팅",
    goal: "Codex가 폴더를 읽고, 파일을 만들고, 결과물을 저장하는 작업 환경을 이해합니다.",
    duration: "8분",
    output: "프로젝트 폴더 연결",
    files: ["samples/", "assets/", "docs/"],
    checks: [
      "Codex 프로젝트 폴더가 선택되었습니다.",
      "샘플 파일 목록을 확인했습니다.",
      "결과물 저장 위치를 정했습니다."
    ],
    instructorNote: "수강생이 가장 자주 놓치는 부분은 '어느 폴더를 Codex 프로젝트로 선택했는가'입니다. 화면을 같이 보며 폴더명을 천천히 확인하세요.",
    steps: [
      {
        title: "폴더 구조 확인",
        body: "Codex에게 현재 폴더 구조를 설명하게 합니다.",
        prompt: "현재 프로젝트 폴더 구조를 확인하고, 실습에 사용할 파일과 참고 문서를 구분해서 알려줘."
      },
      {
        title: "결과물 저장 규칙 정하기",
        body: "새 결과물은 별도 output 폴더에 만들도록 요청합니다.",
        prompt: "앞으로 만드는 결과물은 codex_outputs 폴더를 만들어 그 안에 저장해줘. 원본 samples 폴더의 파일은 수정하지 말아줘."
      },
      {
        title: "실습 체크리스트 만들기",
        body: "수강생이 끝까지 따라갈 수 있도록 단계별 체크리스트를 만듭니다.",
        prompt: "이 실습 패키지를 처음 쓰는 수강생을 위해, 오늘 따라 할 순서를 7단계 체크리스트로 만들어줘."
      }
    ]
  },
  {
    id: "lesson-browser",
    nav: "3강-2: 인앱브라우저",
    title: "3강-2. 인앱브라우저로 웹 자료 요약하기",
    goal: "웹 화면을 읽고 요약하거나 정기 브리핑으로 확장하는 흐름을 이해합니다.",
    duration: "10분",
    output: "공지 요약 또는 브리핑 초안",
    files: ["docs/source_notes.md"],
    checks: [
      "웹 자료에서 제목과 핵심 내용을 분리했습니다.",
      "행동 필요 사항을 별도 표시했습니다.",
      "자동화 요청으로 확장하는 문장을 확인했습니다."
    ],
    instructorNote: "실제 그룹웨어 접근은 기관별 권한이 다르므로, 화면 조작 원리와 요약 형식에 집중하세요. 민감 자료는 화면 공유 전에 반드시 확인하게 합니다.",
    steps: [
      {
        title: "최신 공지 요약",
        body: "게시판의 최신 글을 읽고 핵심 요약을 요청합니다.",
        prompt: "인앱브라우저에 그룹웨어 있다. 게시판 공지사항중 최신 5개 내용 핵심 요약해줘."
      },
      {
        title: "행동 필요 사항 분리",
        body: "마감일, 신청, 제출처럼 수강생이 놓치기 쉬운 항목을 분리합니다.",
        prompt: "요약한 공지 중 마감일, 시행일, 참석, 신청, 제출처럼 행동이 필요한 항목만 따로 표로 정리해줘."
      },
      {
        title: "정기 브리핑 자동화 문장",
        body: "반복 업무를 자동화 요청으로 바꿉니다.",
        prompt: "매일 아침 9시에 보라매병원 그룹웨어의 게시판 > 공지사항 최신 5개 게시물을 확인해서 핵심 브리핑을 만들어줘. 제목, 게시일, 본문, 이미지 안내문, 첨부파일명이나 중요 링크를 가능한 범위에서 읽고, 마감일·시행일·참석·신청·제출 같은 행동 필요 사항은 눈에 띄게 정리해줘. 같은 내용을 연결된 구글 이메일로도 보내줘."
      }
    ]
  },
  {
    id: "lesson-cleanup",
    nav: "3강-3: 컴퓨터 정리",
    title: "3강-3. 컴퓨터 정리는 실행보다 계획이 먼저입니다",
    goal: "다운로드 폴더를 바로 이동/삭제하지 않고, 분류 계획과 dry run을 먼저 만드는 안전한 자동화를 배웁니다.",
    duration: "12분",
    output: "정리 계획 Markdown",
    files: ["docs/source_notes.md"],
    checks: [
      "삭제 없이 계획서부터 만들었습니다.",
      "중복 후보와 민감 파일을 분리했습니다.",
      "dry run 항목을 확인했습니다."
    ],
    instructorNote: "파일 정리는 자동화의 좋은 예시이지만 위험도 있습니다. '삭제하지 말고 먼저 계획'이라는 문장을 프롬프트에 넣는 습관을 강조하세요.",
    steps: [
      {
        title: "가능 여부와 계획 묻기",
        body: "바로 실행하지 않고 계획부터 물어봅니다.",
        prompt: "다운로드 폴더 파일 정리할 수 있나? 계획은?"
      },
      {
        title: "삭제 금지 조건 넣기",
        body: "실제 이동이나 삭제 없이 Markdown 계획서만 만들게 합니다.",
        prompt: "먼저 실제 파일은 이동하거나 삭제하지 말고, 다운로드 폴더에 어떤 파일이 있는지 확인한 뒤 어떤 기준으로 분류할지 Markdown 계획서로 만들어줘."
      },
      {
        title: "분류 기준 지정",
        body: "파일 확장자, 수정일, 키워드 기준을 명확히 줍니다.",
        prompt: "파일 확장자, 수정일, 파일명 키워드를 기준으로 문서, 데이터, 설치 파일, 압축 파일, 미디어, 웹 파일, 디자인 자료, 코드/설정 파일, 수동 검토 대상으로 나눠줘."
      },
      {
        title: "민감 파일 보호",
        body: "개인정보와 계정 정보 가능성이 있는 파일은 별도 검토로 둡니다.",
        prompt: "중복 후보와 개인정보나 계정 정보가 들어 있을 수 있는 민감 파일은 자동 삭제하지 말고, 별도 수동 검토 대상으로 표시해줘."
      },
      {
        title: "dry run 목록 요청",
        body: "실제 이동 전 검토 가능한 목록을 만듭니다.",
        prompt: "실제 정리 전에 원래 경로, 이동 예정 경로, 분류 근거, 중복 후보 여부, 수동 검토 여부가 들어간 dry run 목록을 먼저 만들어줘."
      }
    ]
  },
  {
    id: "lesson-schedule",
    nav: "3강-4: 근무 스케줄표",
    title: "3강-4. 근무표 이미지를 구조화 데이터로 바꾸기",
    goal: "이미지 근무표를 OCR과 Excel 산출물로 변환하는 흐름을 이해합니다.",
    duration: "12분",
    output: "근무표 Excel",
    files: ["samples/schedule_sample_image.jpg", "assets/preview-schedule-parsed.png"],
    preview: {
      src: "assets/preview-schedule-parsed.png",
      caption: "근무표 OCR 결과 예시"
    },
    checks: [
      "개인정보가 포함된 자료는 익명화했습니다.",
      "원본 이미지와 변환 표를 함께 확인했습니다.",
      "자동 인식 결과는 사람이 검토했습니다."
    ],
    instructorNote: "근무표는 실무 체감도가 높지만 개인정보 위험도 큽니다. 실제 병원 자료 대신 익명화 샘플로만 실습하게 하세요.",
    safety: "실제 근무표에는 개인정보와 근무 정보가 포함될 수 있습니다. 교육용 샘플 또는 익명화 자료만 사용하세요.",
    steps: [
      {
        title: "원본 이미지 확인",
        body: "샘플 근무표 이미지의 행, 열, 날짜 구조를 확인합니다.",
        prompt: "samples/schedule_sample_image.jpg 파일을 확인하고, 이 이미지에서 표로 만들 수 있는 정보가 무엇인지 먼저 설명해줘."
      },
      {
        title: "Excel 변환 계획",
        body: "OCR 결과를 바로 믿지 않고 변환 계획과 검토 기준을 세웁니다.",
        prompt: "이 근무표 이미지를 Excel로 옮기는 계획을 세워줘. 원본 이미지 시트, OCR 결과 시트, 검토 필요 항목을 나눠줘."
      },
      {
        title: "결과물 검토 기준",
        body: "자동 인식 결과에서 사람이 확인해야 할 부분을 분리합니다.",
        prompt: "근무표 OCR 결과를 검토할 때 오류가 많이 생길 수 있는 칸과 사람이 꼭 확인해야 할 기준을 체크리스트로 정리해줘."
      }
    ]
  },
  {
    id: "lesson-ch4",
    nav: "3강-5: 의료 AI 데이터",
    title: "3강-5. AI 의료 현장 일자리 변화 데이터",
    goal: "공개 자료를 작은 데이터셋으로 정리하고 Excel 결과물로 만드는 실습입니다.",
    duration: "15분",
    output: "Excel 1개, 차트 1개, 요약 시트 1개",
    files: ["samples/ch4_ai_medical_jobs.csv", "samples/ai_medical_jobs_change_data.xlsx"],
    checks: [
      "데이터가 6행 이하입니다.",
      "출처가 명확합니다.",
      "요약 시트에 인사이트와 액션이 있습니다."
    ],
    instructorNote: "이 챕터의 핵심은 거대한 분석이 아니라 작고 검토 가능한 Excel 파일을 완성하는 경험입니다.",
    steps: [
      {
        title: "데이터 찾기",
        body: "병원 AI 도입률, 자동화 업무, 새 역량을 중심으로 작게 정리합니다.",
        prompt: "AI 의료 현장 일자리 변화 데이터를 찾아줘. 병원 AI 도입률, 자동화되는 업무, 새로 중요해지는 역량을 중심으로 5개 이내로 정리해줘."
      },
      {
        title: "Excel 파일 만들기",
        body: "칼럼 구조를 지정해 Codex가 바로 파일을 만들 수 있게 합니다.",
        prompt: "찾은 데이터를 엑셀 파일로 정리해줘. 칼럼은 지역/기관, 변화 영역, 이전 수치, 최근 수치, 변화 폭, 영향을 받는 직무, 필요한 역량으로 해줘."
      },
      {
        title: "정렬 시트 추가",
        body: "최근 수치가 큰 순서대로 별도 시트를 만듭니다.",
        prompt: "최근 수치가 큰 순서대로 정렬한 시트를 추가해줘. 무료 실습용이니 행은 6개 이하로 유지해줘."
      },
      {
        title: "차트 생성",
        body: "변화 폭이 큰 항목 5개만 가로 막대 차트로 만듭니다.",
        prompt: "변화 폭이 큰 항목 5개를 가로 막대 차트로 만들어줘. 시트 이름은 차트로 해줘."
      },
      {
        title: "요약 시트 작성",
        body: "병원 직원 관점의 준비 액션까지 넣습니다.",
        prompt: "요약 시트에 인사이트 3줄과 병원 직원이 지금 준비할 액션 3가지를 적어줘."
      }
    ]
  },
  {
    id: "lesson-ch5",
    nav: "3강-6: 위내시경 카드뉴스",
    title: "3강-6. 위내시경 환자 안내문 카드뉴스",
    goal: "문서형 안내문을 핵심 메시지 3개와 환자용 카드뉴스 3장으로 바꿉니다.",
    duration: "20분",
    output: "카드 이미지 3장",
    files: [
      "samples/ch5_upper_endoscopy_patient_notice.md",
      "assets/preview-cardnews-01.png",
      "assets/preview-cardnews-02.png",
      "assets/preview-cardnews-03.png"
    ],
    preview: {
      src: "assets/preview-cardnews-01.png",
      caption: "위내시경 카드뉴스 예시"
    },
    checks: [
      "카드가 3장입니다.",
      "카드당 핵심 문장과 설명이 짧습니다.",
      "병원 지시가 우선이라는 문구가 있습니다."
    ],
    instructorNote: "의료 안내문은 보기 좋게 만드는 것보다 오해를 줄이는 것이 먼저입니다. 병원 지시 우선 문구를 반드시 확인하게 하세요.",
    safety: "이 안내문은 교육용 초안입니다. 실제 검사 준비와 복약 조정은 예약한 병원과 의료진 지시가 우선입니다.",
    steps: [
      {
        title: "핵심 메시지 3개 추출",
        body: "검사 전날, 당일, 검사 후로 메시지를 나눕니다.",
        prompt: "위내시경 환자 안내문을 읽고 핵심 메시지 3개를 한 줄씩 뽑아줘. 환자가 검사 전날, 검사 당일, 검사 후에 꼭 기억해야 하는 내용으로 정리해줘."
      },
      {
        title: "카드뉴스 3장 생성",
        body: "비율, 톤, 구성 요소를 명확히 지정합니다.",
        prompt: "위 3개 메시지로 카드뉴스 3장을 만들어줘. 비율은 1:1, 톤은 병원 안내문처럼 차분하고 신뢰감 있게, 각 장은 번호/핵심 문장/짧은 설명으로 구성해줘."
      },
      {
        title: "오해 방지 문구 추가",
        body: "환자에게 실제 지침처럼 오해되지 않게 합니다.",
        prompt: "환자에게 오해가 생기지 않도록 '병원 지시가 우선'이라는 문구를 하단에 작게 넣어줘."
      },
      {
        title: "복잡도 줄이기",
        body: "무료 실습용으로 카드 수와 텍스트 양을 제한합니다.",
        prompt: "이미지가 너무 복잡하면 안 돼. 무료 사용자 실습용이니 카드 3장만 만들고 텍스트는 카드당 2문장 이하로 줄여줘."
      }
    ]
  },
  {
    id: "lesson-ch6",
    nav: "3강-7: 해외 의료 AI",
    title: "3강-7. 해외 의료 AI 적용 현황",
    goal: "공개 자료와 논문 2개를 비교하고 5장짜리 강의 PPT 구조로 정리합니다.",
    duration: "20분",
    output: "논문 비교 노트, 비교 Excel, 5장 PPT",
    files: ["samples/ch6_two_paper_notes.md", "assets/preview-slide-contact-sheet.png"],
    preview: {
      src: "assets/preview-slide-contact-sheet.png",
      caption: "5장 강의 슬라이드 예시"
    },
    checks: [
      "논문은 2개만 사용했습니다.",
      "국가/지역 사례는 3개 이하입니다.",
      "슬라이드당 발표자 노트가 짧습니다."
    ],
    instructorNote: "논문 실습은 깊이보다 구조화가 목표입니다. 수강생에게 연구 대상, 핵심 발견, 현장 시사점만 남기는 훈련이라고 안내하세요.",
    steps: [
      {
        title: "공개 자료와 논문 찾기",
        body: "미국, 영국, 글로벌 관점이 보이는 자료로 제한합니다.",
        prompt: "해외 의료 AI 적용 현황을 보여주는 공개 자료와 논문 2개만 찾아줘. 미국, 영국, 글로벌 임상 적용 관점이 보이면 좋겠어."
      },
      {
        title: "논문 2개 비교",
        body: "연구 대상, 핵심 발견, 현장 시사점만 남깁니다.",
        prompt: "두 논문을 비교해줘. 각 논문마다 연구 대상, 핵심 발견 2개, 병원 현장 적용 시사점 1개만 정리해줘."
      },
      {
        title: "5장 PPT 만들기",
        body: "표지, 현황, 논문 비교, 체크리스트, 마무리 구조로 압축합니다.",
        prompt: "해외 의료 AI 적용 현황을 5장짜리 PPT로 만들어줘. 1장 표지, 2장 해외 도입 현황, 3장 논문 2개 비교, 4장 병원 적용 체크리스트, 5장 마무리로 구성해줘."
      },
      {
        title: "발표자 노트 추가",
        body: "각 슬라이드 발표 시간을 30초 내외로 제한합니다.",
        prompt: "각 슬라이드 발표자 노트를 30초 분량으로 짧게 붙여줘. 무료 실습용이니 표와 문장은 최소화해줘."
      },
      {
        title: "출처 정리",
        body: "의료 AI 자료는 출처 확인이 핵심입니다.",
        prompt: "출처 목록을 마지막 슬라이드 하단 또는 별도 메모로 정리해줘."
      }
    ]
  }
];

const stateKey = "codex-practice-kit-progress-v1";
const instructorKey = "codex-practice-kit-instructor-v1";

const navEl = document.querySelector("#lessonNav");
const stackEl = document.querySelector("#lessonStack");
const progressBar = document.querySelector("#progressBar");
const progressText = document.querySelector("#progressText");
const progressCount = document.querySelector("#progressCount");
const toastEl = document.querySelector("#toast");
const instructorToggle = document.querySelector("#toggleInstructor");

let completed = loadProgress();
let activeLessonId = lessons[0].id;

function iconPath(name) {
  const icons = {
    copy: '<path d="M9 9h10v10H9zM5 5h10v10"/>',
    done: '<path d="M5 13l4 4L19 7"/>'
  };
  return icons[name] || "";
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function loadProgress() {
  try {
    const raw = localStorage.getItem(stateKey);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveProgress() {
  localStorage.setItem(stateKey, JSON.stringify(completed));
}

function getStepId(lessonId, stepIndex) {
  return `${lessonId}::${stepIndex}`;
}

function countSteps() {
  return lessons.reduce((sum, lesson) => sum + lesson.steps.length, 0);
}

function countDone() {
  return Object.values(completed).filter(Boolean).length;
}

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toastEl.classList.remove("show");
  }, 1800);
}

async function copyText(text) {
  const normalized = text.trim();
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(normalized);
    return;
  }

  const area = document.createElement("textarea");
  area.value = normalized;
  area.setAttribute("readonly", "");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  document.body.appendChild(area);
  area.select();
  document.execCommand("copy");
  area.remove();
}

function selectPromptNear(button) {
  const card = button.closest(".prompt-box");
  const prompt = card ? card.querySelector(".prompt-text") : null;
  if (!prompt) return false;

  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(prompt);
  selection.removeAllRanges();
  selection.addRange(range);
  prompt.focus?.();
  return true;
}

function renderNav() {
  navEl.innerHTML = lessons.map((lesson, index) => `
    <a class="nav-link${lesson.id === activeLessonId ? " active" : ""}" href="#${lesson.id}" data-nav-id="${lesson.id}">
      <span>${String(index + 1).padStart(2, "0")}</span>
      <span>${escapeHtml(lesson.nav)}<small>${escapeHtml(lesson.duration)} · ${escapeHtml(lesson.output)}</small></span>
    </a>
  `).join("");
}

function renderLessons() {
  stackEl.innerHTML = lessons.map((lesson, lessonIndex) => `
    <article class="lesson-card" id="${lesson.id}" data-lesson-id="${lesson.id}">
      <header class="lesson-header">
        <div>
          <p class="section-label">Chapter ${String(lessonIndex + 1).padStart(2, "0")}</p>
          <h3>${escapeHtml(lesson.title)}</h3>
          <p>${escapeHtml(lesson.goal)}</p>
        </div>
        <div class="lesson-meta">
          <span class="meta-pill">${escapeHtml(lesson.duration)}</span>
          <span class="meta-pill">${escapeHtml(lesson.output)}</span>
        </div>
      </header>
      <div class="lesson-body">
        <div class="step-list">
          ${lesson.safety ? `<div class="safety-inline">${escapeHtml(lesson.safety)}</div>` : ""}
          ${lesson.steps.map((step, stepIndex) => renderStep(lesson, step, stepIndex)).join("")}
        </div>
        <aside class="lesson-aside">
          ${renderAssetPanel(lesson)}
          ${renderChecksPanel(lesson)}
          ${lesson.preview ? renderPreviewPanel(lesson.preview) : ""}
          <section class="instructor-note">
            <h4>강사용 스크립트</h4>
            <p>${escapeHtml(lesson.instructorNote)}</p>
          </section>
        </aside>
      </div>
    </article>
  `).join("");
}

function renderStep(lesson, step, stepIndex) {
  const stepId = getStepId(lesson.id, stepIndex);
  const done = Boolean(completed[stepId]);
  return `
    <section class="step-card" data-step-id="${stepId}">
      <div class="step-top">
        <span class="step-index">${stepIndex + 1}</span>
        <div>
          <h4>${escapeHtml(step.title)}</h4>
          <p>${escapeHtml(step.body)}</p>
        </div>
        <button class="check-button${done ? " done" : ""}" type="button" data-check="${stepId}">
          <svg viewBox="0 0 24 24" aria-hidden="true">${iconPath("done")}</svg>
          ${done ? "완료됨" : "완료 체크"}
        </button>
      </div>
      <div class="prompt-box">
        <div class="prompt-toolbar">
          <span>Codex 프롬프트</span>
          <button class="copy-button" type="button" data-copy="${escapeHtml(step.prompt)}">
            <svg viewBox="0 0 24 24" aria-hidden="true">${iconPath("copy")}</svg>
            프롬프트 복사
          </button>
        </div>
        <pre class="prompt-text">${escapeHtml(step.prompt)}</pre>
      </div>
    </section>
  `;
}

function renderAssetPanel(lesson) {
  return `
    <section class="asset-panel">
      <h4>준비 파일</h4>
      <ul class="file-list">
        ${lesson.files.map((file) => `<li><code>${escapeHtml(file)}</code></li>`).join("")}
      </ul>
    </section>
  `;
}

function renderChecksPanel(lesson) {
  return `
    <section class="checks-panel">
      <h4>잘 된 결과물 기준</h4>
      <ul class="check-list">
        ${lesson.checks.map((check) => `<li>${escapeHtml(check)}</li>`).join("")}
      </ul>
    </section>
  `;
}

function renderPreviewPanel(preview) {
  return `
    <section class="preview-panel">
      <h4>미리보기</h4>
      <img src="${escapeHtml(preview.src)}" alt="${escapeHtml(preview.caption)}">
      <p>${escapeHtml(preview.caption)}</p>
    </section>
  `;
}

function updateProgress() {
  const total = countSteps();
  const done = countDone();
  const percent = total ? Math.round((done / total) * 100) : 0;
  progressBar.style.width = `${percent}%`;
  progressText.textContent = `${percent}%`;
  progressCount.textContent = `완료된 단계 ${done} / ${total}`;
}

function setInstructorMode(value) {
  document.body.classList.toggle("instructor-on", value);
  localStorage.setItem(instructorKey, value ? "1" : "0");
  instructorToggle.setAttribute("aria-pressed", value ? "true" : "false");
}

function bindEvents() {
  document.addEventListener("click", async (event) => {
    const copyButton = event.target.closest("[data-copy]");
    if (copyButton) {
      try {
        await copyText(copyButton.dataset.copy || "");
        showToast("프롬프트를 복사했습니다.");
      } catch {
        const selected = selectPromptNear(copyButton);
        showToast(selected ? "프롬프트를 선택했습니다. Ctrl+C로 복사하세요." : "복사에 실패했습니다. 텍스트를 직접 선택해 주세요.");
      }
      return;
    }

    const checkButton = event.target.closest("[data-check]");
    if (checkButton) {
      const id = checkButton.dataset.check;
      completed[id] = !completed[id];
      saveProgress();
      renderLessons();
      updateProgress();
      showToast(completed[id] ? "완료로 표시했습니다." : "완료 표시를 해제했습니다.");
      return;
    }

    const navLink = event.target.closest("[data-nav-id]");
    if (navLink) {
      activeLessonId = navLink.dataset.navId;
      renderNav();
    }

    const copyAllButton = event.target.closest("[data-copy-all]");
    if (copyAllButton) {
      const lesson = lessons.find((item) => item.id === activeLessonId) || lessons[0];
      const prompts = lesson.steps.map((step, index) => `${index + 1}. ${step.prompt}`).join("\n\n");
      try {
        await copyText(prompts);
        showToast("현재 챕터 프롬프트를 모두 복사했습니다.");
      } catch {
        showToast("복사에 실패했습니다.");
      }
    }
  });

  document.querySelector("#resetProgress").addEventListener("click", () => {
    completed = {};
    saveProgress();
    renderLessons();
    updateProgress();
    showToast("진행률을 초기화했습니다.");
  });

  instructorToggle.addEventListener("click", () => {
    setInstructorMode(!document.body.classList.contains("instructor-on"));
  });

  const observer = new IntersectionObserver((entries) => {
    const visible = entries
      .filter((entry) => entry.isIntersecting)
      .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (visible) {
      activeLessonId = visible.target.dataset.lessonId;
      renderNav();
    }
  }, { threshold: [0.2, 0.45, 0.7] });

  document.querySelectorAll("[data-lesson-id]").forEach((lesson) => observer.observe(lesson));
}

function init() {
  renderNav();
  renderLessons();
  updateProgress();
  setInstructorMode(localStorage.getItem(instructorKey) === "1");
  bindEvents();
}

init();
