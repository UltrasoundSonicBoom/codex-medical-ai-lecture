# Design Tokens

이 패키지는 Figma 템플릿형 화면 구성을 HTML/CSS로 옮기기 위해 디자인 토큰을 먼저 정의했습니다.

## Color

| Token | Value | Usage |
|---|---|---|
| `--figma-color-ink-950` | `#101828` | 제목, 주요 버튼, 강한 텍스트 |
| `--figma-color-ink-600` | `#526171` | 본문 보조 텍스트 |
| `--figma-color-paper-000` | `#ffffff` | 주요 패널 배경 |
| `--figma-color-paper-050` | `#f8fafc` | 페이지 배경, 보조 패널 |
| `--figma-color-line-100` | `#d9e3ea` | 경계선 |
| `--figma-color-mint-500` | `#2e7c62` | 완료 상태, 안전한 진행 |
| `--figma-color-blue-500` | `#3568a8` | 강사용 정보 |
| `--figma-color-coral-500` | `#e2695b` | CTA, 복사 버튼, 강조 |
| `--figma-color-gold-050` | `#fff8db` | 의료 안전 안내 |

## Spacing

| Token | Value |
|---|---:|
| `--figma-space-1` | `4px` |
| `--figma-space-2` | `8px` |
| `--figma-space-3` | `12px` |
| `--figma-space-4` | `16px` |
| `--figma-space-5` | `20px` |
| `--figma-space-6` | `24px` |
| `--figma-space-8` | `32px` |
| `--figma-space-10` | `40px` |
| `--figma-space-12` | `48px` |

## Radius

| Token | Value | Usage |
|---|---:|---|
| `--figma-radius-xs` | `4px` | Code labels |
| `--figma-radius-sm` | `6px` | Small controls |
| `--figma-radius-md` | `8px` | Buttons, prompt boxes |
| `--figma-radius-lg` | `16px` | Panels |
| `--figma-radius-xl` | `24px` | Main boards |

## Component Patterns

- App shell: left sticky navigation plus right content canvas.
- Board container: white surface, 24px radius, subtle border, large shadow.
- Lesson card: header, step list, right-side asset/check panels.
- Prompt block: toolbar plus scrollable prompt body.
- CTA image: standalone SVG, reused in hero and final section.
- State: incomplete, done, copied, instructor mode.

## Accessibility Rules

- Text does not scale with viewport width except major headings via `clamp`.
- Buttons have visible text plus SVG icons.
- Progress is represented by text and bar, not color alone.
- Instructor notes are hidden by default and toggled with `aria-pressed`.
