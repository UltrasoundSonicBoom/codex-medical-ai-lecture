# 출처 노트

- [ONC Health IT Data Brief: Hospital Trends in the Use, Evaluation, and Governance of Predictive AI, 2023-2024](https://healthit.gov/data/data-briefs/hospital-trends-use-evaluation-and-governance-predictive-ai-2023-2024/)  
  활용: 미국 병원의 예측 AI 도입률, 청구/일정 자동화 증가, 병원 유형별 격차
- [OECD Artificial Intelligence and the Health Workforce, 2024](https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/artificial-intelligence-and-the-health-workforce_c8e4433d/9a31d8af-en.pdf)  
  활용: AI가 의료 인력을 대체하기보다 행정업무 부담을 줄이고 역할을 재편한다는 메시지
- [ASGE: Understanding Upper Endoscopy](https://www.asge.org/home/for-patients/patient-information/understanding-upper-endoscopy)  
  활용: 위내시경 준비, 금식, 약물 상담, 검사 후 주의 증상 안내
- [Mayo Clinic: Upper endoscopy](https://www.mayoclinic.org/tests-procedures/endoscopy/about/pac-20395197)  
  활용: 검사 준비와 회복 안내의 일반 원칙 확인
- [npj Digital Medicine: Global physician perspectives on AI in healthcare across 50 countries and territories](https://www.nature.com/articles/s41746-026-02726-y)  
  활용: 50개 국가/지역 의사 설문 기반의 글로벌 AI 수용성 논문
- [International Journal of Medical Informatics: A multinational study on AI adoption, clinical implementers' perspectives](https://www.sciencedirect.com/science/article/pii/S1386505624000406)  
  활용: 임상 현장 적용자가 말하는 검증, 워크플로우, 규제, 리터러시 과제
- [FDA: Artificial Intelligence-Enabled Medical Devices](https://www.fda.gov/medical-devices/software-medical-device-samd/artificial-intelligence-enabled-medical-devices)  
  활용: 미국 AI 의료기기 인허가 사례와 진료영역 분포 확인
- [GOV.UK: AI to speed up lung cancer diagnosis deployed in NHS hospitals](https://www.gov.uk/government/news/ai-to-speed-up-lung-cancer-diagnosis-deployed-in-nhs-hospitals)  
  활용: 영국 NHS AI 진단 도입 사례와 공공 투자 규모
